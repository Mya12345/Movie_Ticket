<?php
include 'connection.php';

if (isset($_POST['view_more'])) {
    $name=$_POST['name'];
    $description=$_POST['description'];
    $image=$_POST['image'];
//    $quantity=1;
   $select_cart=mysqli_query($conn,"SELECT * FROM `cart` WHERE cart_name='$name'");
   if (mysqli_num_rows($select_cart)>0) {
    $message[]='movie already added in your cart';
    # code...
   }else{
    $query="INSERT INTO `cart` (`cart_name`,`cart_description`,`cart_image`) VALUES ('$name','$description','$image')";
    $insert_query=mysqli_query($conn,$query);
    $message[]='movie added in your cart';
   }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
      <!-- CSS FILES -->        

      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">

      <link rel="preconnect" href="https://fonts.googleapis.com">
        
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

        <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400&family=Sono:wght@200;300;400;500;700&display=swap" rel="stylesheet">
                        
        <link rel="stylesheet" href="./Public/css/bootstrap.min.css">

        <link rel="stylesheet" href="./Public/css/bootstrap-icons.css">

        <link rel="stylesheet" href="./Public/css/owl.carousel.min.css">
        
        <link rel="stylesheet" href="./Public/css/owl.theme.default.min.css">

        <link href="./Public/css/templatemo-pod-talk.css" rel="stylesheet">
</head>
<body>

<!-- header -->
<header>
    <nav class="navbar navbar-expand-lg" style="background-color:rgba(125, 131, 212, 0.5);">
                <div class="container">
                    
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav ms-lg-auto">
                            <li class="nav-item">
                                <a class="nav-link active" href="index.php">Home</a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="about.php">About</a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="contact.php">Contact</a>
                            </li>
                        </ul>


<div class="dropdown">
  <a class="btn btn-secondary dropdown-toggle" href="theater1.php" role="button" data-bs-toggle="dropdown" aria-expanded="false">
    Theater
  </a>

  <ul class="dropdown-menu">
    <li><a class="dropdown-item" href="#">Theater-1</a></li>
    <li><a class="dropdown-item" href="theater2.php">Theater-2</a></li>
    <li><a class="dropdown-item" href="theater3.php">Theater-3</a></li>
  </ul>
            </div>
                
                    </div>
                </div>
            </nav>
    </header>

<?php
if (isset($message)) {
    foreach($message as $message){
        echo '
        <div class="message">
        <span>'.$message.' <i class="bi bi-x" onclick="this.parentElement.style.display=`none`"></i></span></div>';
    }
}
?>

<section class="trending-podcast-section section-padding">

                <div class="container">
                    <div class="row">

                        <div class="col-lg-12 col-12">
                            <div class="section-title-wrap mb-5">
                                <h4 class="section-title">Theater-1</h4>
                            </div>
                        </div>


            <?php
        $select_products=mysqli_query($conn,"SELECT * FROM `products`");
        if (mysqli_num_rows($select_products)>0) {
            while($fetch_products=mysqli_fetch_assoc($select_products)){
                ?>


                 <div class="col-lg-4 col-12 mb-4 mb-lg-0">
                 <div class="custom-block custom-block-full">

                <!-- <form method="post" class="card_image"> -->
                    <!-- <div class="card" style="width:15rem; text-align: center; justify-content: center; margin-right: 20px;margin-bottom: 30px; "> -->
                    <div class="custom-block-image-wrap">   
                    
                    <img src="image/<?php echo $fetch_products['image']; ?>" style="height:180px; width:100%">
                    
                    </div>

                    <div class="custom-block-info">
                   
                        <h5 class="mb-2">
                        <a href="detail-page.html">
                        <h3><?php echo $fetch_products['product_name'];?></h3>
                        </a>
                        </h5>
                        <div class="profile-block d-flex">
                        <div class="price"><?php echo $fetch_products['product_description'];?></div>
                        </div>
                        <input type="hidden" name="name" value="<?php echo $fetch_products['product_name']; ?>">
                        <input type="hidden" name="description" value="<?php echo $fetch_products['product_description']; ?>">
                        <input type="hidden" name="image" value="<?php echo $fetch_products['image']; ?>">
                        <a href="indexx.html"><input type="button" name="view_more" value="Booking" class="btn btn-primary"></a>
                        </div>
                    </div>
            </div>
            
            <?php
            }
        }
        ?>    
                    </div>
                </div>
            </section>
</body>
</html>



 