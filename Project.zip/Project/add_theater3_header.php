
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
 
    <title>Document</title>
</head>
<body >
    <header>
        <div class="flex">
            <a href="" class="logo">Admin Online Movie Ticket</a>
            <div class="navbar">

                <a href="admin_page.php">Home</a>
                <div class="dropdown">
  <a class="btn btn-secondary dropdown-toggle" href="theater1.php" role="button" data-bs-toggle="dropdown" aria-expanded="false">
    Theater
  </a>

  <ul class="dropdown-menu">
    <li><a class="dropdown-item" href="admin_page.php">Theater-1</a></li>
    <li><a class="dropdown-item" href="add_theater2.php">Theater-2</a></li>
    <li><a class="dropdown-item" href="add_theater3.php">Theater-3</a></li>
  </ul>
            </div>
                <a href="admin.php"> Movies</a>
                <a href="#">Booking</a>
                <div class="ms-4">
                            <a href="#section_3" class="btn custom-btn custom-border-btn smoothscroll">Logout</a>
                        </div>

            </div>
            <!-- <a href="cart.php" class="cart"><i class="bi bi-cart-check-fill"></i> <span>0</span> </a> -->
            
        </div>
    </header>
</body>
</html>