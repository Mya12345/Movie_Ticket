<?php
session_start();
if (!isset($_SESSION["user"])) {
    header("Location: home.php");
    # code...
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="register_style.css">
    <link rel="stylesheet" href="./Public/css/swiper-bundle.min.css">
    <link rel="stylesheet" href="./Public/css/home_style.css">

    
    <title>User Dashboard</title>
</head>
<body background="./Public/image/movie6.jpg">
   
     <header>
        <h2 class="logo">Movie Ticket</h2>
        <nav class="navigation">
            <a href="#">Home</a>
            <a href="about.php">About</a>
            <a href="contact.php">Contact</a>
            <a href="index_page.php"><button class="btnLogout-popdown" type="button">Logout</button></a>
            
        </nav>
    </header>

    <div class="slide-container swiper">
        <div class="slide-content">
            <div class="card-wrapper swiper-wrapper">

                <div class="card swiper-slide">
                    <div class="image-content">
                        <span class="overlay"></span>
                            <div class="card-image">
                                <img src="./Public/image/m1.jpg" alt="" class="card-img">
                            </div>
                    </div>
                    <div class="card-content">
                        <h2 class="name">Theater-1</h2>
                        <p class="description"> </p><br><br><br><br>
                        <!-- <button class="button"> View More</button> -->
                    </div>
                </div>

                <div class="card swiper-slide">
                    <div class="image-content">
                        <span class="overlay"></span>
                            <div class="card-image">
                                <img src="./Public/image/m1.jpg" alt="" class="card-img">
                            </div>
                    </div>
                    <div class="card-content">
                        <h2 class="name">ဇာတ်ကားအမည်- သားရှင်</h2>
                        <p class="description">ပါဝင်သရုပ်ဆောင်သူ <br> မိုးအောင်ရင် ၊  စိုးမြတ်သူဇာ ၊ဖွေးဖွေး</p>
                        <button class="button"> View More</button>
                    </div>
                </div>

                <div class="card swiper-slide">
                    <div class="image-content">
                        <span class="overlay"></span>
                            <div class="card-image">
                                <img src="./Public/image/m2.jpg" alt="" class="card-img">
                            </div>
                    </div>
                    <div class="card-content">
                        <h2 class="name">ဇာတ်ကားအမည်- သားရှင်</h2>
                        <p class="description">ပါဝင်သရုပ်ဆောင်သူ <br> မိုးအောင်ရင် ၊  စိုးမြတ်သူဇာ ၊ဖွေးဖွေး</p>
                        <button class="button"> View More</button>
                    </div>
                </div>

                <div class="card swiper-slide">
                    <div class="image-content">
                        <span class="overlay"></span>
                            <div class="card-image">
                                <img src="./Public/image/m4.jpg" alt="" class="card-img">
                            </div>
                    </div>
                    <div class="card-content">
                        <h2 class="name">ဇာတ်ကားအမည်- သားရှင်</h2>
                        <p class="description">ပါဝင်သရုပ်ဆောင်သူ <br> မိုးအောင်ရင် ၊  စိုးမြတ်သူဇာ ၊ဖွေးဖွေး</p>
                        <button class="button"> View More</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="swiper-button-next swiper-navBtn"></div>
        <div class="swiper-button-prev swiper-navBtn"></div>
        <div class="swiper-pagination"></div>
    </div>

    <div class="slide-container swiper">
        <div class="slide-content">
            <div class="card-wrapper swiper-wrapper">

                <div class="card swiper-slide">
                    <div class="image-content">
                        <span class="overlay"></span>
                            <div class="card-image">
                                <img src="./Public/image/m3.jpg" alt="" class="card-img">
                            </div>
                    </div>
                    <div class="card-content">
                        <h2 class="name">Theater-2</h2>
                        <p class="description"> </p><br><br><br><br>
                        <!-- <button class="button"> View More</button> -->
                    </div>
                </div>

                <div class="card swiper-slide">
                    <div class="image-content">
                        <span class="overlay"></span>
                            <div class="card-image">
                                <img src="./Public/image/m4.jpg" alt="" class="card-img">
                            </div>
                    </div>
                    <div class="card-content">
                        <h2 class="name">ဇာတ်ကားအမည်- သားရှင်</h2>
                        <p class="description">ပါဝင်သရုပ်ဆောင်သူ <br> မိုးအောင်ရင် ၊  စိုးမြတ်သူဇာ ၊ဖွေးဖွေး</p>
                        <button class="button"> View More</button>
                    </div>
                </div>

                <div class="card swiper-slide">
                    <div class="image-content">
                        <span class="overlay"></span>
                            <div class="card-image">
                                <img src="./Public/image/m2.jpg" alt="" class="card-img">
                            </div>
                    </div>
                    <div class="card-content">
                        <h2 class="name">ဇာတ်ကားအမည်- သားရှင်</h2>
                        <p class="description">ပါဝင်သရုပ်ဆောင်သူ <br> မိုးအောင်ရင် ၊  စိုးမြတ်သူဇာ ၊ဖွေးဖွေး</p>
                        <button class="button"> View More</button>
                    </div>
                </div>

                <div class="card swiper-slide">
                    <div class="image-content">
                        <span class="overlay"></span>
                            <div class="card-image">
                                <img src="./Public/image/m1.jpg" alt="" class="card-img">
                            </div>
                    </div>
                    <div class="card-content">
                        <h2 class="name">ဇာတ်ကားအမည်- သားရှင်</h2>
                        <p class="description">ပါဝင်သရုပ်ဆောင်သူ <br> မိုးအောင်ရင် ၊  စိုးမြတ်သူဇာ ၊ဖွေးဖွေး</p>
                        <button class="button"> View More</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="swiper-button-next swiper-navBtn"></div>
        <div class="swiper-button-prev swiper-navBtn"></div>
        <div class="swiper-pagination"></div>
    </div>

    <div class="slide-container swiper">
        <div class="slide-content">
            <div class="card-wrapper swiper-wrapper">

                <div class="card swiper-slide">
                    <div class="image-content">
                        <span class="overlay"></span>
                            <div class="card-image">
                                <img src="./Public/image/m1.jpg" alt="" class="card-img">
                            </div>
                    </div>
                    <div class="card-content">
                        <h2 class="name">Theater-3</h2>
                        <p class="description"> </p><br><br><br><br>
                        <!-- <button class="button"> View More</button> -->
                    </div>
                </div>

                <div class="card swiper-slide">
                    <div class="image-content">
                        <span class="overlay"></span>
                            <div class="card-image">
                                <img src="./Public/image/m1.jpg" alt="" class="card-img">
                            </div>
                    </div>
                    <div class="card-content">
                        <h2 class="name">ဇာတ်ကားအမည်- သားရှင်</h2>
                        <p class="description">ပါဝင်သရုပ်ဆောင်သူ <br> မိုးအောင်ရင် ၊  စိုးမြတ်သူဇာ ၊ဖွေးဖွေး</p>
                        <button class="button"> View More</button>
                    </div>
                </div>

                <div class="card swiper-slide">
                    <div class="image-content">
                        <span class="overlay"></span>
                            <div class="card-image">
                                <img src="./Public/image/m1.jpg" alt="" class="card-img">
                            </div>
                    </div>
                    <div class="card-content">
                        <h2 class="name">ဇာတ်ကားအမည်- သားရှင်</h2>
                        <p class="description">ပါဝင်သရုပ်ဆောင်သူ <br> မိုးအောင်ရင် ၊  စိုးမြတ်သူဇာ ၊ဖွေးဖွေး</p>
                        <button class="button"> View More</button>
                    </div>
                </div>

                <div class="card swiper-slide">
                    <div class="image-content">
                        <span class="overlay"></span>
                            <div class="card-image">
                                <img src="./Public/image/m1.jpg" alt="" class="card-img">
                            </div>
                    </div>
                    <div class="card-content">
                        <h2 class="name">ဇာတ်ကားအမည်- သားရှင်</h2>
                        <p class="description">ပါဝင်သရုပ်ဆောင်သူ <br> မိုးအောင်ရင် ၊  စိုးမြတ်သူဇာ ၊ဖွေးဖွေး</p>
                        <button class="button"> View More</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="swiper-button-next swiper-navBtn"></div>
        <div class="swiper-button-prev swiper-navBtn"></div>
        <div class="swiper-pagination"></div>
    </div>
    


</body>
    <!-- Javascript -->
    <script src="./Public/script/swiper-bundle.min.js"></script>

    <!-- home_scriptJS -->
    <script src="./Public/script/home_script.js"></script>
</html>