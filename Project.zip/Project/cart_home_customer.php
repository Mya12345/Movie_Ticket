<?php
include 'connection.php';

if (isset($_POST['view_more'])) {
    $name=$_POST['name'];
    $description=$_POST['description'];
    $image=$_POST['image'];
   $quantity=1;
   $select_cart=mysqli_query($conn,"SELECT * FROM `cart` WHERE cart_name='$name'");
   if (mysqli_num_rows($select_cart)>0) {
    $message[]='product already added in your cart';
    # code...
   }else{
    $query="INSERT INTO `cart` (`cart_name`,`cart_description`,`image`) VALUES ('$name','$description','$image')";
    $insert_query=mysqli_query($conn,$query);
    $message[]='product added in your cart';
   }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="./Public/css/register_style.css">
    <link rel="stylesheet" href="./Public/css/swiper-bundle.min.css">
    <link rel="stylesheet" href="./Public/css/home_style.css">

    
    <title>User Dashboard</title>
</head>
<body>


<?php
if (isset($message)) {
    foreach($message as $message){
        echo '
        <div class="message">
        <span>'.$message.' <i class="bi bi-x" onclick="this.parentElement.style.display=`none`"></i></span></div>';
    }
}
?>
   
     <header>
        <h2 class="logo">Movie Ticket</h2>
        <nav class="navigation">
            <a href="#">Home</a>
            <a href="about.php">About</a>
            <a href="contact.php">Contact</a>
            <a href="#">Theater-1</a>
            <a href="#th2">Theater-2</a>
            <a href="#th3">Theater-3</a>
            <a href="index_page.php"><button class="btnLogout-popdown" type="button">Logout</button></a>
            
        </nav>
    </header>
    

    <div> <h2 class="th_name">Theater-1</h2></div>
    <div class="slide-container swiper" id="">
        <div class="slide-content">
            <div class="card-wrapper swiper-wrapper">
           
           
            <?php
        $select_products=mysqli_query($conn,"SELECT * FROM `products`");
        if (mysqli_num_rows($select_products)>0) {
            while($fetch_products=mysqli_fetch_assoc($select_products)){
                ?>
     

            <div class="card swiper-slide">
            
    
    
                <!-- <form method="post" class="card_image"> -->
                    <!-- <div class="image-content" style="width:15rem; text-align: center; justify-content: center; margin-right: 20px;margin-bottom: 30px; "> -->
                    <div class="image-content">  
                        <span class="overlay" style="background-color: #616bf7;"></span>
                        <div class="card-image" id="card_image" 
                        style=" position: relative;
                                 height: 250px;
                                 width: 250px;
                                 border-radius:10% ;
                                 background: #fff;
                                 padding: 3px;">
                            <img src="image/<?php echo $fetch_products['image']; ?>" class="card-img"  id="card_img" 
                            style=" height: 100%;
                                     width: 100%;
                                     object-fit: cover;
                                     border-radius: 10%;
                                     border: 4px solid #fff;">
                        </div>
                    </div>  

                        <div class="card-content" >
                        <h3><?php echo $fetch_products['product_name'];?></h3>
                        <div class="price">$<?php echo $fetch_products['product_description'];?>/-</div>

                        <input type="hidden" class="title_name" name="name" value="<?php echo $fetch_products['product_name']; ?>">
                        <input type="hidden" class="title_description" name="description" value="<?php echo $fetch_products['product_description']; ?>">
                        <input type="hidden" class="card-img" name="image" value="<?php echo $fetch_products['image']; ?>">
                        <input type="submit" class="button" name="view_more" value="View More" class="btn btn-primary">
                        </div>
                      
                    </div>
                    <?php
            }
        }
        ?>
                <!-- </form> -->
            </div>
           
           
            </div>
            
        </div>
        <div class="swiper-button-next swiper-navBtn"></div>
        <div class="swiper-button-prev swiper-navBtn"></div>
        <div class="swiper-pagination"></div>
       
    </div>

    <div> <h2 class="th_name">Theater-2</h2></div>
    <div class="slide-container swiper" id="th2">
        <div class="slide-content">
            <div class="card-wrapper swiper-wrapper">
           
           
            <?php
        $select_products=mysqli_query($conn,"SELECT * FROM `products`");
        if (mysqli_num_rows($select_products)>0) {
            while($fetch_products=mysqli_fetch_assoc($select_products)){
                ?>
     

            <div class="card swiper-slide">
            
    
    
                <form method="post" class="card_image">
                    <!-- <div class="image-content" style="width:15rem; text-align: center; justify-content: center; margin-right: 20px;margin-bottom: 30px; "> -->
                    <div class="image-content">  
                        <span class="overlay"></span>
                        <div class="card-image">
                            <img src="image/<?php echo $fetch_products['image']; ?>" class="card-img">
                        </div>
                    </div>  

                        <div class="card-content" >
                        <h3><?php echo $fetch_products['product_name'];?></h3>
                        <div class="price">$<?php echo $fetch_products['product_description'];?>/-</div>

                        <input type="hidden" class="title_name" name="name" value="<?php echo $fetch_products['product_name']; ?>">
                        <input type="hidden" class="title_description" name="price" value="<?php echo $fetch_products['product_description']; ?>">
                        <input type="hidden" class="card-img" name="image" value="<?php echo $fetch_products['image']; ?>">
                        <input type="submit" class="button" name="add_to_cart" value="Add to cart" class="btn btn-primary">
                        </div>
                      
                    </div>
                    <?php
            }
        }
        ?>
                </form>
            </div>
           
           
            </div>
            
        </div>
        <div class="swiper-button-next swiper-navBtn"></div>
        <div class="swiper-button-prev swiper-navBtn"></div>
        <div class="swiper-pagination"></div>
       
    </div>

    <div> <h2 class="th_name">Theater-3</h2></div>
    <div class="slide-container swiper" id="th3">
        <div class="slide-content">
            <div class="card-wrapper swiper-wrapper">
           
           
            <?php
        $select_products=mysqli_query($conn,"SELECT * FROM `products`");
        if (mysqli_num_rows($select_products)>0) {
            while($fetch_products=mysqli_fetch_assoc($select_products)){
                ?>
     

            <div class="card swiper-slide">
            
    
    
                <!-- <form method="post" class="card_image"> -->
                    <!-- <div class="image-content" style="width:15rem; text-align: center; justify-content: center; margin-right: 20px;margin-bottom: 30px; "> -->
                    <div class="image-content">  
                        <span class="overlay"></span>
                        <div class="card-image">
                            <img src="image/<?php echo $fetch_products['image']; ?>" class="card-img">
                        </div>
                    </div>  

                        <div class="card-content" >
                        <h3><?php echo $fetch_products['product_name'];?></h3>
                        <div class="price">$<?php echo $fetch_products['product_description'];?>/-</div>

                        <input type="hidden" class="title_name" name="name" value="<?php echo $fetch_products['product_name']; ?>">
                        <input type="hidden" class="title_description" name="price" value="<?php echo $fetch_products['product_description']; ?>">
                        <input type="hidden" class="card-img" name="image" value="<?php echo $fetch_products['image']; ?>">
                        <input type="submit" class="button" name="add_to_cart" value="Add to cart" class="btn btn-primary">
                        </div>
                      
                    </div>
                    <?php
            }
        }
        ?>
                <!-- </form> -->
            </div>
           
           
            </div>
            
        </div>
        <div class="swiper-button-next swiper-navBtn"></div>
        <div class="swiper-button-prev swiper-navBtn"></div>
        <div class="swiper-pagination"></div>
       
     </div>
     
    


</body>
    <!-- Javascript -->
    <script src="./Public/script/swiper-bundle.min.js"></script>

    <!-- home_scriptJS -->
    <script src="./Public/script/home_script.js"></script>
</html>