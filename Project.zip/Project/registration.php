<?php
session_start();
if (isset($_SESSION["user"])) {
    header("Location: home.php");
    # code...
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="./Public/css/register_style.css">
    <link rel="stylesheet" href="./Public/css/home_style.css">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">

<link rel="preconnect" href="https://fonts.googleapis.com">
  
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400&family=Sono:wght@200;300;400;500;700&display=swap" rel="stylesheet">
                  
  <link rel="stylesheet" href="./Public/css/bootstrap.min.css">

  <link rel="stylesheet" href="./Public/css/bootstrap-icons.css">

  <link rel="stylesheet" href="./Public/css/owl.carousel.min.css">
  
  <link rel="stylesheet" href="./Public/css/owl.theme.default.min.css">

  <link href="./Public/css/templatemo-pod-talk.css" rel="stylesheet">
</head>
<body style="background-color:rgba(125, 131, 212, 0.5);">
<header>
<nav class="navbar navbar-expand-lg" style="background-color:rgba(125, 131, 212, 0.5);">

        <!-- <h2 class="logo">Movie Ticket</h2> -->
        <div class="container">
                <!-- <a class="navbar-brand me-lg-5 me-0" href="index.html">
                        <img src="./Public/image/m4.jpg" class="logo-image img-fluid" alt="templatemo pod talk">
                    </a> -->
                    
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav ms-lg-auto">
                            <li class="nav-item">
                                <a class="nav-link active" href="login.php">Home</a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="about.php">About</a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="contact.php">Contact</a>
                            </li>
                        </ul>
</div>
</div>
    </header>
    <div class="container">
        <?php
        // print_r($_POST);
        if(isset($_POST["submit"])){
            $fullName=$_POST["fullname"];
            $email=$_POST["email"];
            $password=$_POST["password"];
            $passwordRepeat=$_POST["repeat_password"];

            $passwordHash=password_hash($password,PASSWORD_DEFAULT);

            $errors=array();

            if (empty($fullName) OR empty($email) OR empty($password) OR empty($passwordRepeat) ) {
                array_push($errors,"All fields are required");
            }
            if (!filter_var($email,FILTER_VALIDATE_EMAIL)) {
            array_push($errors,"Email is not valid");

            }
            if (strlen($password)<8) {
            array_push($errors,"Password must be at least 8 characters long");
            }
            if ($password!==$passwordRepeat) {
                array_push($errors,"Password does not match");
            }
            require_once "database.php";
            $sql="SELECT * FROM users WHERE email = '$email'";
            $result=mysqli_query($conn,$sql);
            $rowCount=mysqli_num_rows($result);
            if ($rowCount>0) {
                array_push($errors,"Email already exists");
            }
            if (count($errors)>0) 
            foreach ($errors as $error) {
                echo "<div class='alert alert-danger'>$error</div>";
            }else{
                
                $sql= "INSERT INTO users(full_name,email,password) VALUES (?,?,?)";
                $stmt= mysqli_stmt_init($conn);
                $preparestmt= mysqli_stmt_prepare($stmt,$sql);
                if ($preparestmt) {
                    mysqli_stmt_bind_param($stmt,"sss",$fullName,$email,$passwordHash);
                    mysqli_stmt_execute($stmt);
                    echo "<div class='alert alert-success'>You are registered successfully.</div>";
                    
                }else{
                    die("Something went wrong");

                }

                
            }

                
        }
        
        ?>
        <form action="registration.php" method="post" class="form1" style="margin-top:100px;">
            <h1>Register Here</h1>
            <div class="form-group">
                <input type="text" class="box" name="fullname" placeholder="Full Name:">
            </div>
            <div class="form-group">
                <input type="email" class="box" name="email" placeholder="Email:">
            </div>
            <div class="form-group">
                <input type="password" class="box" name="password" placeholder="Password:">
            </div>
            <div class="form-group">
                <input type="password" class="box" name="repeat_password" placeholder="Confirm Password:">
            </div>
            <div class="form-btn">
                <a href="login.php"><input type="submit" class="btn btn-primary" name="submit" value="register" id="submit1"></a>
            </div>

        
        <div class="txt"><p>Already Registered?  <a href="login.php" style=" color: red;">Login Here</a></p></div>
        </form>
    </div>
    
</body>
</html>