<?php
    include 'connection.php';

    if (isset($_POST["add_movie"])) {
        $name= $_POST["name"];
        $description= $_POST["description"];
        $image= $_POST["image"];
        $image_tmp_name = $_FILES["image"]["tmp_name"];
        $image_folder= "image/".$image;

        $query="INSERT INTO `products` (`product_name`,`product_description`,`image` ) VALUES ('$name','$description','$image')";
        $insert_query=mysqli_query($conn,$query);

        if($insert_query){
            move_uploaded_file($image_tmp_name, $image_folder);
            $message[]='movie added successfully';
            header('location:admin.php');

        }else{
            $message[]='movie did not added successfully';
        }

    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- bootstrapCSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
    <link rel="stylesheet" type="text/css" href="./Public/css/product_form_style.css">

    <title>Admin</title>
</head>
<body>
<!-- header -->
<!-- <header>
    <nav class="navbar navbar-expand-lg" style="background-color:rgba(125, 131, 212, 0.5);">
                <div class="container">
                    
                    <div class="collapse navbar-collapse" id="navbarNav">
                    <div class="dropdown">
  <a class="btn btn-secondary dropdown-toggle" href="theater1.php" role="button" data-bs-toggle="dropdown" aria-expanded="false">
    Theater
  </a>

  <ul class="dropdown-menu">
    <li><a class="dropdown-item" href="product_form.php">Theater-1</a></li>
    <li><a class="dropdown-item" href="add_theater2.php">Theater-2</a></li>
    <li><a class="dropdown-item" href="add_theater3.php">Theater-3</a></li>
  </ul>
            </div>
                        <ul class="navbar-nav ms-lg-auto">
                            <li class="nav-item">
                                <a class="nav-link active" href="index.php">Home</a>
                            </li>
                            

                            <li class="nav-item">
                                <a class="nav-link" href="about.php">Movies</a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="contact.php">Booking</a>
                            </li>
                        </ul>
            <div class="ms-4">
                            <a href="#section_3" class="btn custom-btn custom-border-btn smoothscroll">Logout</a>
                        </div>
                
                    </div>
                </div>
            </nav>
    </header> -->


    <?php include 'admin_page_header.php'; ?>

   


<?php
if (isset($message)) {
    foreach($message as $message){
        echo '
        <div class="message">
        <span>'.$message.' <i class="bi bi-x" onclick="this.parentElement.style.display=`none`"></i></span></div>';
    }
}
?>


<div class="form">
    <form method="post" enctype="multiprt/form-data" class="form-control">
        <h3>add a new  Movie for Theater-1</h3>
        <input type="text" name="name" placeholder="enter movie name" required id="">
        <input type="text" name="description" min="0" placeholder="enter movie description" required id="">
        <input type="file" name="image" accept="image/png,image/jpg,image/jpeg" required>
        <div class="btn_submit">
        <input type="submit" name="add_movie" value="Add Movie" class="btn" id="">
        </div>
    </form>
</div>

<div class="ms-4" style="justify-content:center; text-align:center; padding-top:20px;">
      <a href="admin.php" class="btn custom-btn custom-border-btn smoothscroll">View Add Movie</a>
      <a href="theater1.php" class="btn custom-btn custom-border-btn smoothscroll">Show Add Movie</a>
 </div>

</body>
<!-- bootstrapJS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

</body>
</html>