<?php

$conn = mysqli_connect("localhost","root","","cinema") or die('connection failed');


?>